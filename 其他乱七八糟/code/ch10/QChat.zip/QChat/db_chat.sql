CREATE DATABASE db_chat;
USE db_chat;
CREATE TABLE tb_user (
id INT AUTO_INCREMENT NOT NULL PRIMARY KEY, 
password VARCHAR(20),
name VARCHAR(20),
sex BOOL, 
birthday DATE,
description TINYTEXT
) charset=gb2312;




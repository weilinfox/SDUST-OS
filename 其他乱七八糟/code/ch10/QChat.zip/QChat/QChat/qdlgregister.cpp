#include "qdlgregister.h"
#include "ui_qdlgregister.h"
#include <QMessageBox>
#include <QHostAddress>
#include "common.h"
QDlgRegister::QDlgRegister(QString ip, QString port, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QDlgRegister)
{
    ui->setupUi(this);

    this->ip = ip;
    this->port = port;
    tcpSocket = new QTcpSocket(this);
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

QDlgRegister::~QDlgRegister()
{
    delete ui;
}

void QDlgRegister::on_btnReg_clicked()
{
    QString name = ui->lineName->text().trimmed();
    password = ui->linePSW->text().trimmed();
    QString password2 = ui->linePSW2->text().trimmed();

    if (name.isEmpty())  {
        QMessageBox::warning(NULL, tr("提示"), tr("昵称不能为空."));
        return;
    }
    else if ( (password != password2) || password.isEmpty())  {
        QMessageBox::warning(NULL, tr("提示"), tr("密码不能为空且两次输入要一致."));
        return;
    }

    tcpSocket->abort();
    tcpSocket->connectToHost(QHostAddress(ip),(quint16)port.toUInt());
    //发送注册信息
    quint8 msgType = MSG_CLIENT_REG;
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_4);
    out << (quint16)0 << msgType << name << password;
    out.device()->seek(0);
    out << (quint16)(block.size() - sizeof(quint16));
    tcpSocket->write(block);
}

void QDlgRegister::onReadyRead()
{
    QByteArray block = tcpSocket->readAll();
    QDataStream in(&block, QIODevice::ReadOnly);
    quint16 dataGramSize;
    quint8 msgType;
    in >> dataGramSize >> msgType>>userid;

    if ( MSG_SERVER_REG_FAILED == msgType )
    {
        QMessageBox::warning(NULL, tr("消息"), tr("注册失败."));
    }
    else if (MSG_SERVER_REG_SUCCESS == msgType)
    {
        QMessageBox::information(this, "消息", "注册成功.");
        this->close();
    }
}

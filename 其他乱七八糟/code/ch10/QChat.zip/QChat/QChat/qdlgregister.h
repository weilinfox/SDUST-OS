/*************************************/
//注册对话框类:QDlgRegister
/*************************************/
#ifndef QDLGREGISTER_H
#define QDLGREGISTER_H

#include <QDialog>
#include <QTcpSocket>
namespace Ui {
class QDlgRegister;
}

class QDlgRegister : public QDialog
{
    Q_OBJECT

public:
    explicit QDlgRegister(QString ip, QString port, QWidget *parent = 0);
    ~QDlgRegister();

    quint32 userid;//返回给登录窗口
    QString password;//返回给登录窗口

private slots:

    void on_btnReg_clicked();
    void onReadyRead();

private:
    Ui::QDlgRegister *ui;

    QTcpSocket *tcpSocket;
    QString ip;
    QString port;
};

#endif // QDLGREGISTER_H

#include <QApplication>
#include <QTextCodec>
#include "qdlglogin.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QTextCodec::setCodecForLocale(QTextCodec::codecForLocale());

    QDlgLogin dlgLogin;
    dlgLogin.show();

    return a.exec();
}

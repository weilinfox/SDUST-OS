#include "qdlggchat.h"
#include "ui_qdlggchat.h"
#include "common.h"
#include <QMessageBox>
#include <QColorDialog>
#include "qmsg.h"
#include <QDateTime>

QDlgGChat::QDlgGChat(quint32 userID, QString ip, QString port, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QDlgGChat)
{
    ui->setupUi(this);
    this->setWindowTitle(QString::number(userID));

    this->ip = ip;
    this->port = port;
    this->userid = userID;
    this->flag = false;
    this->init();

    connect(ui->txtSend, SIGNAL(currentCharFormatChanged(QTextCharFormat)),
            this, SLOT(currentFormatChanged(const QTextCharFormat)));
}

QDlgGChat::~QDlgGChat()
{
    delete ui;
}

//初始化
void QDlgGChat::init()
{
    QMsg msg;
    msg.type=MSG_CLIENT_CONN;
    msg.senderID=userid;
    msg.tarIP=QHostAddress(ip).toIPv4Address();
    msg.tarPort=(quint16)port.toUInt()+1;
    udpSocket.sendMsg(&msg);

    connect(&udpSocket, SIGNAL(readyRead()), this, SLOT(recvMsg()));
}

//发送按钮
void QDlgGChat::on_btnSend_clicked()
{
    //获取消息内容
    QString strInfo=ui->txtSend->toHtml();
    if(strInfo.trimmed().isEmpty())  return;

    //发送消息
    QMsg msg;
    msg.type=MSG_CLIENT_GROUP_CHAT;
    msg.senderID=userid;
    msg.strInfo=strInfo;
    msg.tarIP=QHostAddress(ip).toIPv4Address();
    msg.tarPort=(quint16)port.toUInt()+1;

    udpSocket.sendMsg(&msg);

    //本地显示
    ui->txtSend->clear();
    ui->txtSend->setFocus();
}

//接收消息
void QDlgGChat::recvMsg()
{
    QByteArray block;
    quint8 msgType;
    quint16 size;
    QHostAddress peerIp;
    quint16 peerPort;
    block.resize(udpSocket.pendingDatagramSize());
    this->udpSocket.readDatagram(block.data(),block.size(),&peerIp,&peerPort);
    QDataStream in(&block,QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_5_4);
    in>>size>>msgType;

    switch (msgType) {
    case MSG_SERVER_USER_ONLINE:
    {
        QList<quint32> listUserid;
        QStringList listName;
        in >>listUserid >> listName;
        ui->listUser->clear();
        for (int i=0; i<listUserid.count(); i++)
        {
            QString itemString;
            itemString = listName.at(i) + "[" + QString::number(listUserid.at(i)) +"]";
            ui->listUser->addItem(itemString);
        }
        ui->lblCount->setText(QString::number(ui->listUser->count()) + "个用户在线");
        break;
    }
    case MSG_CLIENT_GROUP_CHAT:
    {
        QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");

        quint32 peerId;
        QString peerName,word;
        in>>peerId>>peerName>>word;
        QString strInfo=peerName+"("+QString::number(peerId)+") "+time;

        if(peerId==userid)
            ui->txtbrosRecv->setTextColor(Qt::green);
        else
            ui->txtbrosRecv->setTextColor(Qt::blue);
        ui->txtbrosRecv->setCurrentFont(QFont("Times New Roman",12));
        ui->txtbrosRecv->append(strInfo);
        ui->txtbrosRecv->append(word);

        break;
    }
    case MSG_SERVER_CHANGE_USER_STATUS://有用户新登录
    {
        quint32 peerId;
        QString peerName;
        in >> peerId >> peerName;
        if (this->userid != peerId)//如果登录的不是自己
        {
            QString newItem;
            newItem.append(peerName + "["+peerId+"]");
            for (int i=0; i < ui->listUser->count(); i++)//如果该用户已在列表，则删除
            {
                if (ui->listUser->item(i)->text() == newItem)
                {
                    delete ui->listUser->takeItem(i);
                }
            }
            ui->listUser->addItem(newItem);//将该用户加入列表
            ui->lblCount->setText(QString::number(ui->listUser->count()) + "个用户在线");
        }
        break;
    }
    case MSG_CLIENT_LOGOUT:
    {
        quint32 peerId;
        QString peerName;
        in >> peerId >> peerName;

        QString newItem;
        newItem.append(peerName + "["+peerId+"]");
        for (int i=0; i < ui->listUser->count(); i++)//如果该用户已在列表，则删除
        {
            if (ui->listUser->item(i)->text() == newItem)
            {
                delete ui->listUser->takeItem(i);
            }
        }
        ui->lblCount->setText(QString::number(ui->listUser->count()) + "个用户在线");
        break;
    }
    default:
        break;
    }
}

void QDlgGChat::closeEvent(QCloseEvent *e)
{
    QMsg msg;
    msg.type=MSG_CLIENT_LOGOUT;
    msg.senderID=userid;
    msg.tarIP=QHostAddress(ip).toIPv4Address();
    msg.tarPort=(quint16)port.toUInt()+1;

    udpSocket.sendMsg(&msg);
}

void QDlgGChat::on_btnClose_clicked()
{
    close();
}

//字体族
void QDlgGChat::on_coboxFont_currentFontChanged(const QFont &f)
{
    ui->txtSend->setCurrentFont(f);
    ui->txtSend->setFocus();
}

//字体大小
void QDlgGChat::on_coboxSize_currentIndexChanged(const QString &arg1)
{
    ui->txtSend->setFontPointSize(arg1.toDouble());
    ui->txtSend->setFocus();
}

//加粗
void QDlgGChat::on_toolbtnBold_clicked(bool checked)
{
    if(checked)
        ui->txtSend->setFontWeight(QFont::Bold);
    else
        ui->txtSend->setFontWeight(QFont::Normal);
    ui->txtSend->setFocus();
}

//倾斜
void QDlgGChat::on_toolbtnItalic_clicked(bool checked)
{
    ui->txtSend->setFontItalic(checked);
    ui->txtSend->setFocus();
}

//下划线
void QDlgGChat::on_toolbtnUnderline_clicked(bool checked)
{
    ui->txtSend->setFontUnderline(checked);
    ui->txtSend->setFocus();
}

//颜色
void QDlgGChat::on_toolbtnColor_clicked()
{
    color = QColorDialog::getColor(color, this);
    if (color.isValid()) {
        ui->txtSend->setTextColor(color);
        ui->txtSend->setFocus();
    }
}

void QDlgGChat::currentFormatChanged(const QTextCharFormat &format)
{
    ui->coboxFont->setCurrentFont(format.font());

    // 如果字体大小出错，使用12
    if (format.fontPointSize() < 9)
        ui->coboxSize->setCurrentIndex(3);
    else
        ui->coboxSize->setCurrentIndex( ui->coboxSize->findText(QString::number(format.fontPointSize())));

    ui->toolbtnBold->setChecked(format.font().bold());
    ui->toolbtnItalic->setChecked(format.font().italic());
    ui->toolbtnUnderline->setChecked(format.font().underline());
    color = format.foreground().color();
}

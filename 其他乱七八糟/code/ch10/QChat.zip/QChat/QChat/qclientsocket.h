/////////////////////////////////////////////////////////////////////////////
//客户端UDP套接字:QClientSocket
//主要功能：发送数据
/////////////////////////////////////////////////////////////////////////////
#ifndef QCLIENTSOCKET_H
#define QCLIENTSOCKET_H

#include <QObject>
#include <QUdpSocket>
#include "common.h"
class QMsg;

class QClientSocket : public QUdpSocket
{
    Q_OBJECT
public:
    explicit QClientSocket(QObject *parent = 0);//构造
    ~QClientSocket();

    void sendMsg(QMsg *pMsg);//发送消息
};

#endif // QCLIENTSOCKET_H

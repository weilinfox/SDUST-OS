/*************************************/
//登录对话框类:QDlgLogin
/*************************************/
#ifndef QDLGLOGIN_H
#define QDLGLOGIN_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class QDlgLogin;
}

class QDlgLogin : public QDialog
{
    Q_OBJECT

public:
    explicit QDlgLogin(QWidget *parent = 0);
    ~QDlgLogin();

private slots:
    void on_cmdlinkRegister_clicked();
    void on_btnLogin_clicked();
    void onReadyRead();

    void on_btnServerOk_clicked();

    void on_btnServer_clicked();

    void on_btnServerCancel_clicked();

private:
    Ui::QDlgLogin *ui;

    bool serverOk;
    QString ip;
    QString port;
    quint32 userid;
    QString password;
    QTcpSocket *tcpSocket;
};

#endif // QDLGLOGIN_H

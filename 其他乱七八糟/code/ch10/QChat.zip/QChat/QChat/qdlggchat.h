/*************************************/
//群聊窗口类:QDlgGChat
/*************************************/
#ifndef QDLGGCHAT_H
#define QDLGGCHAT_H

#include <QDialog>
#include  "qclientsocket.h"
#include <QTextCharFormat>

namespace Ui {
class QDlgGChat;
}

class QDlgGChat : public QDialog
{
    Q_OBJECT

public:
    explicit QDlgGChat(quint32 userID, QString ip, QString port, QWidget *parent = 0);
    ~QDlgGChat();

    void init();

protected:
    void closeEvent(QCloseEvent *e);
private:
    Ui::QDlgGChat *ui;

    QString ip;//服务器IP
    QString port;//服务器端口
    quint32 userid;//自己的ID
    QClientSocket udpSocket;
    bool flag;
    QColor color;

private slots:
    void on_btnSend_clicked();
    void recvMsg();
    void on_btnClose_clicked();
    void on_coboxFont_currentFontChanged(const QFont &f);
    void on_coboxSize_currentIndexChanged(const QString &arg1);
    void on_toolbtnBold_clicked(bool checked);
    void on_toolbtnItalic_clicked(bool checked);
    void on_toolbtnUnderline_clicked(bool checked);
    void on_toolbtnColor_clicked();

    void currentFormatChanged(const QTextCharFormat &format);
};

#endif // QDLGGCHAT_H

/*
 * ----消息结构
用于客户端与服务器之间的通信。主要包括:
属性：消息类型、发送者ID、接收者ID（预留）、消息内容等等。
方法：消息数据的打包和解包（加载）。
*/

#ifndef QMSG_H
#define QMSG_H

#include <QObject>
#include <QDataStream>
class QMsg : public QObject
{
    Q_OBJECT
public:
    explicit QMsg(QObject *parent = 0);
    virtual ~QMsg();

    quint8 type;  //消息类型
    quint32 senderID;  //发送者ID
    quint32 tarIP;//目标IP
    quint16 tarPort;//目标port
    QString strInfo;//聊天内容

    QByteArray buf;//数据缓冲区
    virtual  void pack(); //打包消息数据
    virtual  bool load();//解包消息数据
signals:

public slots:
};

#endif // QMSG_H

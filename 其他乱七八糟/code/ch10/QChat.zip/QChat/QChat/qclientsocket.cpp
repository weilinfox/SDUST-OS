#include "qclientsocket.h"
#include "qmsg.h"
#include <QTime>

QClientSocket::QClientSocket(QObject *parent) : QUdpSocket(parent)
{
    this->bind();
}

QClientSocket::~QClientSocket()
{

}

///发送消息
void QClientSocket::sendMsg(QMsg *pMsg)
{
    if(!pMsg)
        return;

    //发送数据
    pMsg->pack();
    writeDatagram(pMsg->buf.data(),pMsg->buf.size(),QHostAddress(pMsg->tarIP),pMsg->tarPort);
}

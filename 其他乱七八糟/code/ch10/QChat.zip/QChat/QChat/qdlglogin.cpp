#include "qdlglogin.h"
#include "ui_qdlglogin.h"

#include "qdlgregister.h"
#include "common.h"
#include <QMessageBox>
#include <QHostAddress>
#include "qdlggchat.h"

QDlgLogin::QDlgLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QDlgLogin)
{
    ui->setupUi(this);

    serverOk=false;
    ui->btnLogin->setEnabled(false);
    ui->cmdlinkRegister->setEnabled(false);

    ui->lineUserID->setPlaceholderText(QString::fromLocal8Bit("账号"));
    ui->linePSW->setPlaceholderText(QString::fromLocal8Bit("密码"));
    ui->linePSW->setEchoMode(QLineEdit::Password);

    tcpSocket=new QTcpSocket(this);
    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));
}

QDlgLogin::~QDlgLogin()
{
    delete ui;
}

///注册
void QDlgLogin::on_cmdlinkRegister_clicked()
{
    QDlgRegister dlgReg(ip,port,this);
    dlgReg.exec();

    //如果注册成功，则直接登录
    userid=dlgReg.userid;
    if(userid>0){
        ui->lineUserID->setText(QString::number(userid));
        ui->linePSW->setText(dlgReg.password);
        on_btnLogin_clicked();
    }
}

///登录
void QDlgLogin::on_btnLogin_clicked()
{
    if (ip.isEmpty() || port.isEmpty())
    {
        QMessageBox::warning(NULL, tr("提示"), tr("请先设置服务器IP和端口"));
    }
    else
    {
        userid=ui->lineUserID->text().trimmed().toUInt();
        password=ui->linePSW->text().trimmed();

        tcpSocket->abort();
        tcpSocket->connectToHost(QHostAddress(ip), (quint16)port.toUInt());
        quint8 msgType = MSG_CLIENT_LOGIN;
        QByteArray block;
        QDataStream out(&block, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_5_4);
        out << (quint16)0 << (quint8)msgType << userid << password;
        out.device()->seek(0);
        out << (quint16)(block.size() - sizeof(quint16));
        tcpSocket->write(block);
    }
}

///读取/处理TCP套接字数据
void QDlgLogin::onReadyRead()
{
    QByteArray block = tcpSocket->readAll();
    QDataStream in(&block, QIODevice::ReadOnly);     //QDataStream in(tcpSocket);
    quint16 dataSize;
    quint8 msgType;
    in >> dataSize >> msgType;

    switch (msgType) {
    case MSG_SERVER_LOGIN_SUCCESS:
    {
        QDlgGChat *dlg=new QDlgGChat(userid,ip,port);
        dlg->show();
        this->close();
        break;
    }
    case MSG_SERVER_LOGIN_ERR_PSW:
    {
        QMessageBox::information(NULL, tr("提示"), tr("密码错误。"));
        ui->linePSW->clear();
        ui->linePSW->setFocus();
        break;
    }
    case MSG_SERVER_LOGIN_ERR_ID:
    {
        QMessageBox::warning(NULL, tr("提示"), tr("该账号不存在，请先注册。"));
        ui->lineUserID->clear();
        ui->linePSW->clear();
        ui->lineUserID->setFocus();
        break;
    }
    case MSG_SERVER_LOGIN_ERR_RELOGIN:
    {
        QMessageBox::information(NULL, tr("提示"), tr("请不要重复登录。"));
        ui->lineUserID->clear();
        ui->linePSW->clear();
        ui->lineUserID->setFocus();
        break;
    }
    default:

        break;
    }
}

///确认服务器设置
void QDlgLogin::on_btnServerOk_clicked()
{
    QString strIP = ui->lineIP->text().trimmed();
    QString strPort = ui->linePort->text().trimmed();

    QRegExp rxIp("\\d+\\.\\d+\\.\\d+\\.\\d+");
    QRegExp rxPort(("[1-9]\\d{3,4}"));
    rxIp.setPatternSyntax(QRegExp::RegExp);
    rxPort.setPatternSyntax(QRegExp::RegExp);

    if (!rxIp.exactMatch(strIP) )
    {
        QMessageBox::critical( NULL, tr("错误"), tr("IP地址不合法.") );
        ui->lineIP->setFocus();
        return;
    }

    if ( !rxPort.exactMatch(strPort))
    {
        QMessageBox::critical( NULL, tr("错误"), tr("端口号不合法.") );
        ui->linePort->setFocus();
        return;
    }

    ip=strIP;
    port=strPort;
    serverOk=true;
    resize(325,200);
    ui->btnLogin->setEnabled(true);
    ui->cmdlinkRegister->setEnabled(true);
}

///显示服务器设置
void QDlgLogin::on_btnServer_clicked()
{
    static bool serverSetup=true;
    if(serverSetup)
        resize(325,200);
    else
    {
        resize(325,360);
        if(serverOk) {
            ui->lineIP->setText(ip);
            ui->linePort->setText(port);
        }
    }
    serverSetup=!serverSetup;
}

///关闭服务器设置
void QDlgLogin::on_btnServerCancel_clicked()
{
    resize(325,200);
}

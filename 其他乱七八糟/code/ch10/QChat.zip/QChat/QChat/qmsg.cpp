#include "qmsg.h"

QMsg::QMsg(QObject *parent) : QObject(parent)
{
    tarIP=0;
    tarPort=0;
}

QMsg::~QMsg()
{
}

void QMsg::pack()
{
    QDataStream out(&buf,QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_4);

    out<<type<<senderID<<strInfo;
}

bool QMsg::load()
{
    QDataStream in(&buf,QIODevice::ReadOnly);
    in.setVersion(QDataStream::Qt_5_4);

    in>>type>>senderID>>strInfo;

    return true;
}


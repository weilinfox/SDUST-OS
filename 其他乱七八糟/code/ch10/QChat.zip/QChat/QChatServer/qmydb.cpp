#include "qmydb.h"
#include <QSqlDriver>
QMyDB::QMyDB(QObject *parent) : QObject(parent)
{

}

QMyDB::~QMyDB()
{

}

void QMyDB::connectDB()
{
    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("db_chat");
    db.setUserName("root");
    db.setPassword("v587");
    if ( !db.open()) {
       QMessageBox::critical(NULL, "连接数据库", "连接失败。");
    }
}

void QMyDB::closeDB()
{
    db.close();
}

bool QMyDB::getUserInfo(quint32 id,QUser *pUser)
{
    bool result=false;

    this->connectDB();
    QSqlQuery  query;
    if (!(query.exec("SELECT * FROM tb_user WHERE id="+QString::number(id))))
        return false;

    if (query.next())   {
            pUser->id=query.value("id").toUInt();
            pUser->password=query.value("password").toString();
            pUser->name=query.value("name").toString();
            pUser->sex=query.value("sex").toBool();
            pUser->birthday=query.value("birthday").toDate();
            pUser->description=query.value("description").toString();

            result=true;
    }
    this->closeDB();
    return result;
}

quint32 QMyDB::newUser(QString password, QString name, bool sex, QDate birthday, QString description)
{
    this->connectDB();
    QSqlQuery  query;

    query.prepare("INSERT INTO tb_user (password, name, sex,birthday,description)"
                  "VALUES (:password, :name,:sex, :birthday,:description)");
    query.bindValue(":password", password);
    query.bindValue(":name", name);
    query.bindValue(":sex", sex);
    query.bindValue(":birthday", birthday);
    query.bindValue(":description", description);

    query.exec();\

    ///返回新用户的ID
    quint32 userid=0;
    query.exec("SELECT LAST_INSERT_ID( )");
    if(query.next())
        userid=query.value(0).toUInt();
    this->closeDB();

    return userid;
}

int QMyDB::getUserList(QList<quint32> *listID, QStringList *listName)
{
    int count=0;

    this->connectDB();
    QSqlQuery  query;
    listID->clear();
    listName->clear();

    ///查询
    if(!(query.prepare("SELECT id, name FROM tb_user")))
        count=-1;

    if(!query.exec())
        count=-1;

    ///数据加入列表
    while (query.next()) {
            listID->append(query.value(0).toUInt());
            listName->append(query.value(1).toString());
    }

    ///获取记录数
    if(db.driver()->hasFeature(QSqlDriver::QuerySize))
        count=query.size();
    else{
        query.last();
        count=query.at()+1;
    }

    this->closeDB();
    return count;
}

#ifndef COMMON
#define COMMON

//消息类型
#define MSG_CLIENT_GROUP_CHAT                 0
#define MSG_CLIENT_CHAT                               1
#define MSG_CLIENT_REG                                 2
#define MSG_CLIENT_LOGIN                             3
#define MSG_CLIENT_CONN                              4

#define MSG_SERVER_REG_SUCCESS                 50
#define MSG_SERVER_REG_FAILED                    51
#define MSG_SERVER_LOGIN_SUCCESS            52
#define MSG_SERVER_LOGIN_ERR_PSW            53
#define MSG_SERVER_LOGIN_ERR_ID                54
#define MSG_SERVER_LOGIN_ERR_RELOGIN    55

#define MSG_SERVER_USER_ONLINE                56
#define MSG_CLIENT_LOGOUT  90
#define MSG_SERVER_CHANGE_USER_STATUS            92

//用户状态
#define STATUS_OFFLINE    0
#define STATUS_ONLINE     1

#endif // COMMON


/**************************************************/
//数据库接口类：QMyDB
//功能：提供数据库访问接口
/**************************************************/
#ifndef QMyDB_H
#define QMyDB_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QMessageBox>
#include <QString>
#include <QStringList>
#include "quser.h"

class QMyDB : public QObject
{
    Q_OBJECT
public:
    explicit QMyDB(QObject *parent = 0);
    ~QMyDB();

    ///数据库操作
    void connectDB();//连接数据库
    void closeDB();//关闭数据库

    ///数据访问接口
    bool getUserInfo( quint32 id,QUser *pUser);//获取用户信息
    quint32 newUser(QString password, QString name, bool sex=true, QDate birthday=QDate::currentDate(),    QString description="");//新建用户
    int getUserList(QList<quint32> *listID, QStringList *listName);//获取用户列表
private:
    QSqlDatabase db;//数据库对象
};

#endif // QMyDB_H

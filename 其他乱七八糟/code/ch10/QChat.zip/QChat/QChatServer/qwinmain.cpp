/****************************************************************************/
//主窗口类实现：QWinMain.cpp
//功能：管理员界面；响应客户端请求
//主要成员：server,udpSocket,onlineUser
/****************************************************************************/
#include "qwinmain.h"
#include "ui_qwinmain.h"
#include <QMessageBox>
#include "common.h"
#include <QNetworkInterface>

///数据库，套接字对象
QMyDB *db;//数据库对象
QUdpSocket *udpSocket;//UDP套接字

///在线用户列表onlineUser操作
QHash<quint32,QUser*>onlineUser;//在线用户列表
void setUserStatus(quint32 userid,quint8 status);
void setUserStatus(quint32 userid,quint8 status,quint32 ip,quint16 port);
void broadcast(QByteArray block);

///构造
QWinMain::QWinMain(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::QWinMain)
{
    ///初始界面
    ui->setupUi(this);
    ui->lblServerIP->clear();
    ui->lblServerPort->clear();

    ///在线用户列表
    model.setHorizontalHeaderItem(0, new QStandardItem(QObject::tr("ID")));
    model.setHorizontalHeaderItem(1, new QStandardItem(QObject::tr("昵称")));
    model.setHorizontalHeaderItem(2, new QStandardItem(QObject::tr("IP")));
    model.setHorizontalHeaderItem(3, new QStandardItem(QObject::tr("端口")));
    ui->tbviewUser->setModel(&model);
    ui->tbviewUser->setColumnWidth(0, 80);
    ui->tbviewUser->setColumnWidth(1, 120);
    ui->tbviewUser->setColumnWidth(2, 120);
    ui->tbviewUser->setColumnWidth(3, 60);
    ui->tbviewUser->setSelectionBehavior(QAbstractItemView::SelectRows);    //设置选中时为整行选中
    ui->tbviewUser->setEditTriggers(QAbstractItemView::NoEditTriggers);       //设置表格的单元为只读属性，即不能编辑
    ui->tbviewUser->setContextMenuPolicy(Qt::CustomContextMenu);//使用右键菜单

    /// 服务状态，数据库初始化
    running=false;
    db=new QMyDB;
}

///析构
QWinMain::~QWinMain()
{
    delete ui;
}

///刷新在线用户列表
void QWinMain::tbviewRefresh()
{
    model.removeRows(0,model.rowCount());
    int i=0;
    foreach (quint32 userid, onlineUser.keys())
    {
        QUser* pUser=onlineUser.value(userid);
        model.setItem(i,0,new QStandardItem(QString::number(userid)));
        model.setItem(i,1,new QStandardItem(pUser->name));
        model.setItem(i,2,new QStandardItem(QHostAddress(pUser->ip).toString()));
        model.setItem(i,3,new QStandardItem(QString::number(pUser->port)));
        i++;
    }
}

///启动/停止服务（ server,udpSocket）
void QWinMain::on_btnStart_clicked()
{
    if ( !running)
    {
        ///通知server监听到达的连接
        if ( !server.listen( QHostAddress::Any,(quint16)8000) )   {
            QMessageBox::critical(NULL, tr("提示"), tr("TCP监听失败 %1.").arg(server.errorString() ) );
            return;
        }

        ///显示服务器IP、端口
        QString ipAddress;
        QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

        for (int i = 0; i < ipAddressesList.size(); ++i) //use the first non-localhost IPv4 address
        {
            if (ipAddressesList.at(i) != QHostAddress::LocalHost
                    && ipAddressesList.at(i).toIPv4Address())
            {
                ipAddress = ipAddressesList.at(i).toString();
                break;
            }
        }

        if (ipAddress.isEmpty())//if we did not find one, use IPv4 localhost
            ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
        ui->lblServerIP->setText(ipAddress);
        ui->lblServerPort->setText(QString::number(server.serverPort()));

        ///UDP绑定
        udpSocket = new QUdpSocket(this);
        if ( !udpSocket->bind(QHostAddress(ipAddress), (quint16)8001 ) )  {
            QMessageBox::critical(NULL, tr("提示"), tr("UDP绑定失败: %1.").arg(udpSocket->errorString() ) );
            return;
        }
        connect(udpSocket, SIGNAL(readyRead()), this, SLOT(onReadDatagrams()));

        ui->btnStart->setText("停止服务");
        running=true;
    }
    else//停止监听
    {
        server.close();
        udpSocket->close();
        ui->btnStart->setText("启动服务");
        running=false;

        ui->lblServerIP->clear();
        ui->lblServerPort->clear();
    }
}

///读取数据报
void QWinMain::onReadDatagrams()
{
    QHostAddress senderIp;
    quint16 senderPort;
    while (udpSocket->hasPendingDatagrams())
    {
        QByteArray block;
        block.resize(udpSocket->pendingDatagramSize());
        if ( -1 == udpSocket->readDatagram(block.data(), block.size(), &senderIp, &senderPort))
            continue;

        processDatagram(block,senderIp.toIPv4Address(),senderPort);
    }
}

///处理数据报
void QWinMain::processDatagram(QByteArray block,quint32 senderIp,quint16 senderPort)
{
    QDataStream in(&block,QIODevice::ReadOnly);
    //quint16 dataGramSize;
    quint8 msgType;

   //in >> dataGramSize >> msgType;
   in >> msgType;

    switch (msgType)   {
    case MSG_CLIENT_CONN://客户端连接
    {
        quint32 id;
        in >> id;

        ///设置用户状态,IP,port
        setUserStatus(id,STATUS_ONLINE,senderIp,senderPort);

        ///向登录用户发送用户列表
        QByteArray block;
        QDataStream out(&block, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_5_4);

        QList<quint32> listID;
        QStringList listName ;
        if(db->getUserList(&listID,&listName)>0){
            quint8 msgType = MSG_SERVER_USER_ONLINE;
            out << (quint16)0 << msgType << listID << listName;
            out.device()->seek(0);
            out << (quint16)(block.size() - sizeof(quint16));
            udpSocket->writeDatagram(block.data(), block.size(),QHostAddress(senderIp),senderPort) ;
        }

        ///广播用户状态
        msgType= MSG_SERVER_CHANGE_USER_STATUS;
        block.clear();
        out.device()->seek(0);
        QUser* pUser=onlineUser.value(id); //由在线用户列表获取用户信息
        out << (quint16)0 << msgType << id << pUser->name;
        out.device()->seek(0);
        out << (quint16)(block.size() - sizeof(quint16));
        broadcast(block);

        ///更新显示
        tbviewRefresh();
        ui->txtLog->append(pUser->name+"（"+QString::number(id)+","+QHostAddress(pUser->ip).toString()+":"+QString::number(pUser->port)+"）上线了");
        break;
    }
    case MSG_CLIENT_LOGOUT://用户退出
    {
        quint32 id;
        in >> id;

        ///广播
        msgType= MSG_CLIENT_LOGOUT;
        QUser* pUser=onlineUser.value(id); //由在线用户列表获取用户信息

        block.clear();
        QDataStream out(&block,QIODevice::WriteOnly);
        out.device()->seek(0);
        out << (quint16)0 << msgType << id <<pUser->name;
        out.device()->seek(0);
        out << (quint16)(block.size() - sizeof(quint16));
        broadcast(block);

        ///更新，显示
        ui->txtLog->append(pUser->name+"（"+QString::number(id)+"）退出了");
        onlineUser.remove(id);
        tbviewRefresh();
        break;
    }
    case MSG_CLIENT_GROUP_CHAT://聊天消息
    {
        quint32 fromID;
        QString fromName,strInfo;
        in >> fromID >> strInfo;

        QUser* pUser=onlineUser.value(fromID); //由在线用户列表获取用户信息
        fromName=pUser->name;

        QByteArray blockRelay;
        QDataStream out(&blockRelay,QIODevice::WriteOnly);
        msgType=MSG_CLIENT_GROUP_CHAT;
        out<< (quint16)0 << msgType<< fromID << fromName << strInfo;

        out.device()->seek(0);
        out << (quint16)(blockRelay.size() - sizeof(quint16));
        broadcast(blockRelay);

        break;
    }
    }//end of switch
}

/***************************在线用户列表onlineUser操作函数****************************************/
///更新/设置用户状态，IP，port
void setUserStatus(quint32 userid,quint8 status)
{

    QUser* pUser=onlineUser.value(userid);
    if(!pUser)
    {
        pUser=new QUser();
        onlineUser.insert(userid,pUser);
        db->getUserInfo(userid,pUser);
    }
    pUser->status=status;
}
void setUserStatus(quint32 userid,quint8 status,quint32 ip,quint16 port)
{

    QUser* pUser=onlineUser.value(userid);
    if(!pUser)
    {
        pUser=new QUser();
        onlineUser.insert(userid,pUser);
        db->getUserInfo(userid,pUser);
    }
    pUser->status=status;
    pUser->ip=ip;
    pUser->port=port;
}

///向在线用户广播数据
void broadcast(QByteArray block)
{
    foreach (quint32 userid, onlineUser.keys())
    {
        QUser* pUser=onlineUser.value(userid);
        udpSocket->writeDatagram(block.data(), block.size(), QHostAddress(pUser->ip), pUser->port) ;
    }
}

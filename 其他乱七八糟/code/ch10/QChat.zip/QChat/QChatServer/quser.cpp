#include "quser.h"

QUser::QUser(QObject *parent) : QObject(parent)
{

}

QUser::~QUser()
{

}


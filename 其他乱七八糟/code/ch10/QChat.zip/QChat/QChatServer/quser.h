/**************************************************/
//用户信息类：QUser
//主要属性：用户ID，昵称，状态，IP，端口号等等。
/**************************************************/
#ifndef QUSER_H
#define QUSER_H

#include <QObject>
#include <QDate>

class QUser : public QObject
{
    Q_OBJECT
public:
    explicit QUser(QObject *parent = 0);
    ~QUser();

    quint32 id;
    QString password;
    QString name;
    bool sex;
    QDate birthday;
    QString description ;
    quint8 status;
    quint32 ip;
    quint16 port;
};

#endif // QUSER_H

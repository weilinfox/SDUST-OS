/**************************************************/
//TCP线程：QTcpThread
//功能：处理TCP连接（来自客户端的注册或登录请求）
/**************************************************/
#ifndef QTCPTHREAD_H
#define QTCPTHREAD_H

#include <QThread>
#include <QTcpSocket>
#include "qmydb.h"

class QTcpThread : public QThread
{
    Q_OBJECT
public:
    explicit QTcpThread(int socketDescriptor, QObject *parent = 0);
    ~QTcpThread();
    void run();

private:
    int socketDescriptor;
    QTcpSocket *tcpSocket;
    QMyDB *db;
signals:
    void error(QTcpSocket::SocketError socketError);
private slots:
    void onReadyRead();
};

#endif // QTCPTHREAD_H

/**************************************************/
//TCP服务器类：QServer
//功能：响应TCP连接
/**************************************************/
#ifndef QSERVER_H
#define QSERVER_H

#include <QTcpServer>

class QServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit QServer(QObject *parent = 0);
    ~QServer();

signals:

public slots:

    ///处理到达的连接请求
protected:
    void incomingConnection(qintptr socketDescriptor);
};

#endif // QSERVER_H

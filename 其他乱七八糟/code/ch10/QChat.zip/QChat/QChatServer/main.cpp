/**************************************************/
//主程序——main.cpp
//主要功能：启动主窗口
/**************************************************/
#include "qwinmain.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QWinMain w;
    w.show();

    return a.exec();
}

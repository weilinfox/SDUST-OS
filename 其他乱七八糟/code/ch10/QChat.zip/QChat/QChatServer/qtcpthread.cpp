#include "qtcpthread.h"
#include "common.h"
#include <QtNetwork>
#include "quser.h"

QTcpThread::QTcpThread(int socketDescriptor, QObject *parent)
    :  QThread(parent),  socketDescriptor(socketDescriptor)
{

}

QTcpThread::~QTcpThread()
{

}

/****************************************************************************
** 创建一个QTcpSocket套接字，用构造时传入的socketDescriptor设置该套接字的描述符，
** 然后将其存入一个内置的未决连接列表（internal　list of pending connections）。
** 最后，发射newConnection() 信号。
****************************************************************************/
void QTcpThread::run()
{
    tcpSocket = new QTcpSocket;

    connect(tcpSocket, SIGNAL(readyRead()), this, SLOT(onReadyRead()));

    if (!tcpSocket->setSocketDescriptor(socketDescriptor))
    {
        emit error(tcpSocket->error());
        return;
    }
    /****************************************************************************
    **进入事件循环（event loop），并等待exit() 被调用，返回传递给exit()的值。
    ** 如果exit() 是通过quit()调用的，则返回值为０。
    ** 调用exec()函数以开始事件处理（event handling）是必要的。
    ****************************************************************************/
    exec();
}

///处理来自客户端的注册或登录请求
void QTcpThread::onReadyRead()
{
    db = new QMyDB;

    QByteArray block = tcpSocket->readAll();
    QDataStream in(&block, QIODevice::ReadOnly);
    quint16 dataSize;
    quint8 msgType;
    in >> dataSize >> msgType;

    switch (msgType)   {
    case MSG_CLIENT_REG://注册
    {
        QString name;
        QString password;
        in >> name >> password;

        //响应
        QByteArray block;
        QDataStream out(&block, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_5_4);

        quint32 userid=db->newUser(password,name) ;
        quint8 msgType;
        if ( 0 == userid)
            msgType = MSG_SERVER_REG_FAILED;
        else
            msgType = MSG_SERVER_REG_SUCCESS;
        out << (quint16)0 << msgType<<userid;
        out.device()->seek(0);
        out << (quint16)(block.size() - sizeof(quint16));
        tcpSocket->write(block);

        break;
    }
    case MSG_CLIENT_LOGIN://登录
    {
        quint32 id;
        QString password;
        in >> id >> password;

        //响应
        QByteArray block;
        QDataStream out(&block, QIODevice::WriteOnly);
        out.setVersion(QDataStream::Qt_5_4);

        QUser user;
        quint8 msgType;
        if(!db->getUserInfo(id,&user))       //账号不存在
            msgType = MSG_SERVER_LOGIN_ERR_ID;
        else if(user.password!= password)      //密码错误
            msgType = MSG_SERVER_LOGIN_ERR_PSW;
        else  {  //成功登录
            msgType = MSG_SERVER_LOGIN_SUCCESS;
        }
        out << (quint16)0 << msgType;
        out.device()->seek(0);
        out << (quint16)(block.size() - sizeof(quint16));
        tcpSocket->write(block);

        break;
    }
    default:
        break;
    }//switch

    db->closeDB();
}

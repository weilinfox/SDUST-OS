﻿/****************************************************************************/
//主窗口类：QWinMain
//功能：管理员界面；响应客户端请求
//主要成员：server,udpSocket,onlineUser
/****************************************************************************/
#ifndef QWINMAIN_H
#define QWINMAIN_H

#include <QMainWindow>
#include "qserver.h"
#include <QtNetwork>
#include "qmydb.h"
#include "quser.h"
#include <QStandardItemModel>

namespace Ui {
class QWinMain;
}

class QWinMain : public QMainWindow
{
    Q_OBJECT

public:
    explicit QWinMain(QWidget *parent = 0);
    ~QWinMain();

private slots:
    void on_btnStart_clicked();//启动/停止服务
    void onReadDatagrams();//读数据报
private:
    Ui::QWinMain *ui;

    ///在线用户列表
    QStandardItemModel model;
    void tbviewRefresh();

    ///TCP服务，UDP服务
    bool running;//服务状态
    QServer server;//TCP服务器对象
    void processDatagram(QByteArray block,quint32 senderIp,quint16 senderPort);//处理数据报
};

#endif // QWINMAIN_H

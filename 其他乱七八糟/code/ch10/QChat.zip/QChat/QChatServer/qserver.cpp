#include "qserver.h"
#include "qtcpthread.h"
QServer::QServer(QObject *parent)   :
         QTcpServer(parent)
{

}

QServer::~QServer()
{

}

void QServer::incomingConnection(qintptr socketDescriptor)
{
    ///启动新线程以响应TCP连接
    QTcpThread  *thread = new QTcpThread(socketDescriptor,this);
    connect(thread, SIGNAL(finished()), thread, SLOT(deleteLater()));
    thread->start();
}

